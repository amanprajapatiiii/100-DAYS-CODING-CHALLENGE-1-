#include <stdio.h>
int main() {
printf("*\n\n");
printf("*\n*\n*\n\n");
printf("*\n*\n*\n*\n*\n\n");
printf("*\n*\n*\n\n");
printf("*\n");
return 0;
}
