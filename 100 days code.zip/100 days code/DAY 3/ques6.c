#include <stdio.h>

int main() {
    int a, b, temp;

    // Input
    printf("Enter first number (a): ");
    scanf("%d", &a);

    printf("Enter second number (b): ");
    scanf("%d", &b);

    // Swapping using a temporary variable
    temp = a;
    a = b;
    b = temp;

    // Output
    printf("After swapping: a = %d, b = %d\n", a, b);

    return 0;
}
