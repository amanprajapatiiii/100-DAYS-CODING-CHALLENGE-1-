#include<stdio.h>
#include<math.h>
int main(){
int n,temp,d,ld,fd,newn;
scanf("%d",&n);
temp=n;
ld=n%10;
d=(int)log10(n);
fd=n/(int)pow(10,d);
newn=ld*(int)pow(10,d)+n%((int)pow(10,d))-ld+fd;
printf("%d",newn);
return 0;
}
