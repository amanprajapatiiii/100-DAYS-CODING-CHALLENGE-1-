#include<stdio.h>
int main(){
int d,f=0;
scanf("%d",&d);
if(d<=5) f=d*2;
else if(d<=10) f=5*2+(d-5)*4;
else if(d<=30) f=5*2+5*4+(d-10)*6;
else{
printf("Membership Cancelled");
return 0;
}
printf("Fine=%d",f);
return 0;
}