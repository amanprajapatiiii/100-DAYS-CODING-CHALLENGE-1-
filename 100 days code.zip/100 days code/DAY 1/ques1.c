#include <stdio.h>

int main() {
    int a, b, c;

    // Input first number
    printf("Enter first number: ");
    scanf("%d", &a);

    // Input second number
    printf("Enter second number: ");
    scanf("%d", &b);

    // Calculate sum
    c = a + b;

    // Display the result
    printf("Sum of %d and %d is: %d\n", a, b, c);

    return 0;
}
